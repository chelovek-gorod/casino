import { Container, Sprite } from "pixi.js";
import { atlases, images } from "../../../app/assets";
import { EventHub, events, setHelpText } from "../../../app/events";
import { setCursorPointer } from "../../../utils/functions";
import { BET_RATIO, FIELD, GAME_CONTAINERS, HELP_TEXT, MAX_BET_RATIO,
    NUMBERS, SECTOR, SECTOR_NUMBERS, SECTOR_SPLIT_NUMBERS, SPIEL, UI } from "../../constants";
import { addBetData, betCurrent, betNearest, removeBet, getBetDataValue,
    isOnSpin, isSingleBetsInSectors, setBet } from "../../state";
import Chip from "./Chip";

const FIELD_TYPE = { spiel: 'spiel', field: 'field' }

function getNearest(number) {
    const index = NUMBERS.indexOf(number)
    const result = []
    
    for (let i = -betNearest; i <= betNearest; i++) {
        let newIndex = (index + i + NUMBERS.length) % NUMBERS.length
        result.push(NUMBERS[newIndex])
    }
    
    return result
}

export default class Field extends Container {
    constructor() {
        super()

        // chips
        this.spielChips = new Container()
        this.fieldChips = new Container()

        // SPIEL
        this.spiel = new Container()
        this.spiel.position.set(
            GAME_CONTAINERS.field.pointSpiel.x, GAME_CONTAINERS.field.pointSpiel.y
        )
        this.addChild(this.spiel)

        this.spielBg = new Sprite(images.spiel_bg)
        this.spiel.addChild(this.spielBg)

        this.sectorsList = {}
        Object.keys(SPIEL.sectors).forEach( sector => {
            this.sectorsList[sector] = new Sprite(atlases.spiel_light.textures[sector])
            this.sectorsList[sector].anchor.set(0.5)
            this.sectorsList[sector].position.set(SPIEL.sectors[sector].x, SPIEL.sectors[sector].y)
            this.sectorsList[sector].numbers = SECTOR_NUMBERS[sector]
            this.sectorsList[sector].splitData = {
                arr: [],
                points: [],
                numbers: []
            }
            SECTOR_SPLIT_NUMBERS[sector].forEach( split => {
                if (split.length > 1) this.sectorsList[sector].splitData.arr.push(split)
                else this.sectorsList[sector].splitData.numbers.push(split[0])
            })
        })
        SPIEL.numbers.forEach( (numberData, index) => {
            this.sectorsList[index] = new Sprite(atlases.spiel_light.textures[index])
            this.sectorsList[index].anchor.set(0.5)
            this.sectorsList[index].position.set(numberData.x, numberData.y)
            this.sectorsList[index].numbers = [index]
            this.sectorsList[index].isPoint = true
            this.sectorsList[index].chip = new Chip(false)
            this.sectorsList[index].chip.position.set(numberData.chipX, numberData.chipY)
        })
        Object.keys(this.sectorsList).forEach( key => {
            this.sectorsList[key].alpha = 0
            this.sectorsList[key].title = key
            this.sectorsList[key].field = FIELD_TYPE.spiel
            setCursorPointer(this.sectorsList[key])
            this.sectorsList[key].on('pointerdown', this.onClick, this)
            this.sectorsList[key].on('pointerup', this.onRelease, this)
            this.sectorsList[key].on('pointerover', this.onHover, this)
            this.sectorsList[key].on('pointerout', this.onOut, this)
            this.spiel.addChild(this.sectorsList[key])
        })

        this.spielTop = new Sprite(images.spiel_top)
        this.spiel.addChild(this.spielTop)

        // FIELD

        this.field = new Container()
        this.field.position.set(
            GAME_CONTAINERS.field.pointField.x, GAME_CONTAINERS.field.pointField.y
        )
        this.addChild(this.field)

        const fieldOffsetY = 0

        this.slotsList = {}
        FIELD.ceils.numbers.forEach( (data, index) => {
            this.slotsList[index] = new Sprite(atlases.field_light.textures[index])
            this.slotsList[index].anchor.set(0.5)
            this.slotsList[index].position.set(data.centerX, data.centerY + fieldOffsetY)
            this.slotsList[index].numbers = [index]
            this.slotsList[index].isPoint = true
            this.slotsList[index].spielChip = this.sectorsList[index].chip
        })
        Object.keys(FIELD.ceils.sections).forEach( section => {
            this.slotsList[section] = new Sprite(atlases.field_light.textures[section])
            this.slotsList[section].anchor.set(0.5)
            this.slotsList[section].position.set(
                FIELD.ceils.sections[section].centerX,
                FIELD.ceils.sections[section].centerY + fieldOffsetY
            )
            this.slotsList[section].numbers = SECTOR_NUMBERS[section]
        })
        Object.keys(this.slotsList).forEach( key => {
            this.slotsList[key].alpha = 0
            this.slotsList[key].title = key
            this.slotsList[key].field = FIELD_TYPE.field
            this.slotsList[key].chip = new Chip()
            this.slotsList[key].chip.position.set(
                this.slotsList[key].position.x, this.slotsList[key].position.y
            )
            setCursorPointer(this.slotsList[key])
            this.slotsList[key].on('pointerdown', this.onClick, this)
            this.slotsList[key].on('pointerup', this.onRelease, this)
            this.slotsList[key].on('pointerover', this.onHover, this)
            this.slotsList[key].on('pointerout', this.onOut, this)
            this.field.addChild(this.slotsList[key])
        })

        this.fieldTop = new Sprite(images.field)
        this.fieldTop.position.set(0, fieldOffsetY)
        this.field.addChild(this.fieldTop)

        this.pointsList = []

        // cross points lights
        let cpl_x = 42
        let cpl_y = fieldOffsetY + 2
        const step_x = 40
        const step_y = 50
        for(let row = 0; row < 3; row++) {
            if (row > 0) {
                for(let top = 0; top < 24; top++) {
                    cpl_x += step_x
                    this.addPoint(cpl_x, cpl_y, row, top, 0)
                }
            }
            
            cpl_x = 2
            cpl_y += step_y
            for(let mid = 0; mid < 12; mid++) {
                cpl_x += step_x + step_x
                this.addPoint(cpl_x, cpl_y, row, mid, 1)
            }

            cpl_x = 42
            cpl_y += step_y

            if (row === 2) {
                for(let bot = 0; bot < 25; bot++) {
                    cpl_x += step_x
                    this.addPoint(cpl_x, cpl_y, row, bot, 3)
                }
            }
        }

        Object.keys(SECTOR_SPLIT_NUMBERS).forEach( key => {
            delete this.sectorsList[key].splitData.arr
        })

        this.clickDuration = 0
        this.clickTarget = null
        this.clickIsActive = false

        this.dolly = new Sprite(images.dolly)
        this.dolly.scale.set(0.7)
        this.dolly.anchor.set(0.5)

        this.dollySpiel = new Sprite(images.dolly)
        this.dollySpiel.scale.set(0.5)
        this.dollySpiel.anchor.set(0.5)

        this.spiel.addChild(this.spielChips)
        this.field.addChild(this.fieldChips)

        EventHub.on(events.startSpin, this.startSpin, this)
        EventHub.on(events.addLog, this.getSpinResult, this)
        EventHub.on(events.clearOneBet, this.clearOneBet, this)
        EventHub.on(events.clearAllBets, this.clearAllBets, this)
    }

    addPoint(x, y, rowIndex, stepIndex, layer) {
        const point = new Sprite(images.point)
        point.anchor.set(0.5)
        point.position.set(x, y)
        point.alpha = 0.01
        point.numbers = layer === 0
            ? FIELD.points.top[rowIndex][stepIndex]
            : layer === 1
            ? FIELD.points.mid[rowIndex][stepIndex]
            : FIELD.points.bot[stepIndex]
        point.isPoint = true
        point.chip = new Chip()
        point.chip.position.set(x, y)
        switch(point.numbers.length) {
            case 2 : point.title = 'pair'; break
            case 3 : point.title = 'street'; break
            case 4 : point.title = 'corner'; break
            case 6 : point.title = 'six line'; break
            default: ''
        }
        this.checkPointSpielSplits(point)
        setCursorPointer(point)
        point.on('pointerdown', this.onClick, this)
        point.on('pointerup', this.onRelease, this)
        point.on('pointerover', this.onHover, this)
        point.on('pointerout', this.onOut, this)
        this.pointsList.push(point)
        this.field.addChild(point)
    }

    checkPointSpielSplits(point) {
        Object.keys(SECTOR_SPLIT_NUMBERS).forEach( key => {
            this.sectorsList[key].splitData.arr.forEach( splitArr => {
                if (point.numbers.length !== splitArr.length) return

                const sortedSplit = [...splitArr].sort()
                const sortedPoint = [...point.numbers].sort()

                if (sortedSplit.every((val, i) => val === sortedPoint[i])) {
                    this.sectorsList[key].splitData.points.push(point)
                }
            })
        })
    }

    userSetBet() {
        // bet in spiel
        if (this.clickTarget.field === FIELD_TYPE.spiel) {

            // nearest
            if (this.clickTarget.numbers.length === 1) {

                const nearestList = getNearest(this.clickTarget.numbers[0])
                if (!setBet(nearestList)) return

                nearestList.forEach( n => {
                    addBetData([n])
                    this.setBetInField(this.slotsList[n])
                })

                

            // sector
            } else {

                if (isSingleBetsInSectors) {

                    if (!setBet(this.clickTarget.numbers)) return

                    this.clickTarget.numbers.forEach( n => {
                        addBetData([+n])
                        this.setBetInField(this.slotsList[n])
                    })

                } else {

                    const pointsNumbers = this.clickTarget.splitData.points.map(p => p.numbers)
                    if(this.clickTarget.title === SECTOR.vois) {
                        pointsNumbers.push(SECTOR_SPLIT_NUMBERS[SECTOR.vois][0])
                    }
                    if (!setBet(
                        this.clickTarget.splitData.numbers, pointsNumbers
                    )) return

                    this.clickTarget.splitData.points.forEach( point => {
                        this.setBetInField(point)
                        if (this.clickTarget.title === SECTOR.vois
                        && point.numbers.join('_') === "0_2_3") {
                            this.setBetInField(point)
                        }
                    })

                    pointsNumbers.forEach(numbers => addBetData(numbers))

                    this.clickTarget.splitData.numbers.forEach( n => {
                        addBetData([+n])
                        this.setBetInField(this.slotsList[n])
                    })
                    
                }

            }

        // bet in field
        } else {
            if (!setBet([], [this.clickTarget.numbers])) return

            addBetData(this.clickTarget.numbers)
            this.setBetInField( this.clickTarget )
        }

        const betValue = getBetDataValue(this.clickTarget.numbers)
        if (betValue > 0) {
            const maxBet = MAX_BET_RATIO[this.clickTarget.numbers.length]
            setHelpText({
                ru: `${HELP_TEXT.betOnHoverBet.ru} ${betValue}. ${HELP_TEXT.betOnHoverMax.ru} ${maxBet}.`,
                en: `${HELP_TEXT.betOnHoverBet.en} ${betValue}. ${HELP_TEXT.betOnHoverMax.en} ${maxBet}.`
            })
        }
    }
    setBetInField(betData) {
        betData.chip.update(betCurrent)
        this.fieldChips.addChild(betData.chip)
        if ('spielChip' in betData) {
            this.spielChips.addChild(betData.spielChip)
        }
    }

    startSpin() {
        this.spiel.removeChild(this.dollySpiel)
        this.field.removeChild(this.dolly)
        this.clickIsActive = false
        this.clickDuration = 0
    }

    getSpinResult(number) {
        const x = this.slotsList[number].position.x
        const y = this.slotsList[number].position.y
        this.dolly.position.set(x + 10, y + 20)
        this.field.addChild(this.dolly)

        const sx = this.sectorsList[number].chip.position.x
        const sy = this.sectorsList[number].chip.position.y
        this.dollySpiel.position.set(sx, sy)
        this.spiel.addChild(this.dollySpiel)
    }

    highlightOn(target) {
        if ('isPoint' in target === false) target.alpha = 0.5
        if (target.title === SECTOR.vois) this.sectorsList[SECTOR.zero].alpha = 0.5
        if (target.field === FIELD_TYPE.spiel && target.numbers.length === 1) {
            const numbers = getNearest(target.numbers[0])
            numbers.forEach( n => {
                this.sectorsList[n].alpha = 0.5
                this.slotsList[n].alpha = 0.5
            })
            return
        }

        target.numbers.forEach( n => {
            this.sectorsList[n].alpha = 0.5
            this.slotsList[n].alpha = 0.5
        })
    }
    highlightOff(target) {
        if ('isPoint' in target === false) target.alpha = 0
        if (target.title === SECTOR.vois) this.sectorsList[SECTOR.zero].alpha = 0
        if (target.field === FIELD_TYPE.spiel && target.numbers.length === 1) {
            const numbers = getNearest(target.numbers[0])
            numbers.forEach( n => {
                this.sectorsList[n].alpha = 0
                this.slotsList[n].alpha = 0
            })
            return
        }
        target.numbers.forEach( n => {
            this.sectorsList[n].alpha = 0
            this.slotsList[n].alpha = 0
        })
    }

    onClick(event) {
        if (isOnSpin) return

        console.log(
            '\ntitle:', event.target.title,
            '\nnumbers:', event.target.numbers,
            '\ntype:', event.target.field,
            '\npos:', event.target.position,
            '\nisRightBtnClick', event.data.button == 2
        )

        this.clickDuration = Date.now()
        this.clickTarget = event.target
        this.clickIsActive = true
    }
    onRelease(event) {
        if (isOnSpin) return

        this.clickIsActive = false
        if (this.clickDuration === 0) return

        const dt = Date.now() - this.clickDuration
        this.clickDuration = 0
        if(dt >= UI.contextOpenMinDuration || event.data.button === 2) {
            console.log(
                'POPUP DATA:',
                '\ntitle:', event.target.title,
                '\nnumbers:', event.target.numbers,
                '\ntype:', event.target.field
            )

            // disable to set and edit bets in spiel field !!!
            if (event.target.field === FIELD_TYPE.spiel) return

            return removeBet(event.target.numbers)
        }

        this.clickTarget = event.target
        this.userSetBet()
    }
    onHover(event) {
        if (isOnSpin) return

        const betValue = getBetDataValue(event.target.numbers)
        if (betValue > 0) {
            const maxBet = MAX_BET_RATIO[event.target.numbers.length]
            setHelpText({
                ru: `${HELP_TEXT.betOnHoverBet.ru} ${betValue}. ${HELP_TEXT.betOnHoverMax.ru} ${maxBet}.`,
                en: `${HELP_TEXT.betOnHoverBet.en} ${betValue}. ${HELP_TEXT.betOnHoverMax.en} ${maxBet}.`
            })
        } else if (event.target.field === FIELD_TYPE.field || event.target.isPoint) {
            const rateSize = BET_RATIO[event.target.numbers.length] - 1
            const maxBet = MAX_BET_RATIO[event.target.numbers.length]
            setHelpText({
                ru: `${HELP_TEXT.betOnHoverRate.ru} ${rateSize}:1. ${HELP_TEXT.betOnHoverMax.ru} ${maxBet}.`,
                en: `${HELP_TEXT.betOnHoverRate.ru} ${rateSize}:1. ${HELP_TEXT.betOnHoverMax.en} ${maxBet}.`
            })
        }
        
        if(this.clickIsActive) {
            this.clickDuration = Date.now()
            this.clickTarget = event.target
        }

        this.highlightOn(event.target)
    }
    onOut(event) {
        if (isOnSpin) return

        this.highlightOff(event.target)

        setHelpText()
    }

    clearOneBet() {
        Object.keys(this.slotsList).forEach( key => {
            if ('chip' in this.slotsList[key]) {
                if (getBetDataValue(this.slotsList[key].numbers) === 0) {
                    this.slotsList[key].chip.update(0)
                    this.fieldChips.removeChild(this.slotsList[key].chip)
                    if ('spielChip' in this.slotsList[key]) {
                        this.spielChips.removeChild(this.slotsList[key].spielChip)
                    }
                }
            }
        })
        this.pointsList.forEach( point => {
            if (getBetDataValue(point.numbers) === 0) {
                point.chip.update(0)
                this.fieldChips.removeChild(point.chip)
            }
        })
    }

    clearAllBets() {
        this.spielChips.removeChildren()
        this.fieldChips.children.forEach(c => c.update(0))
        this.fieldChips.removeChildren()
    }

    kill() {
        EventHub.off(events.startSpin, this.startSpin, this)
        EventHub.off(events.addLog, this.getSpinResult, this)
        EventHub.off(events.clearOneBet, this.clearOneBet, this)
        EventHub.off(events.clearAllBets, this.clearAllBets, this)

        while(this.children.length) {
            if ('kill' in this.children[0]) this.children[0].kill()
            else this.children[0].destroy()
        }
        this.destroy()
    }
}